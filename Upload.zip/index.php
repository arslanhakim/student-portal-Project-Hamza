<?php
/**
 * Root router — sends authenticated users to dashboard,
 * unauthenticated users to login.
 */

require_once __DIR__ . '/config/session.php';

if (isLoggedIn()) {
    header('Location: /dashboard.php');
} else {
    header('Location: /auth/login.php');
}


exit;